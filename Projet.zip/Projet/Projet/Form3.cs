﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        public OracleConnection GetDBConnection()
        {
            string connectionString = "DATA SOURCE = (DESCRIPTION ="
               + "(ADDRESS = (PROTOCOL = TCP)(HOST = LAPTOP-OPCS7AAB)(PORT = 1521))" +
   "(CONNECT_DATA =" +
    " (SERVER = DEDICATED)" +
    " (SERVICE_NAME = XE)" +
  " ) ); USER ID = SYSTEM;Password=manager;";


            OracleConnection conn = new OracleConnection(connectionString);

            //  conn.ConnectionString = connectionString;
            //MessageBox.Show("hhhhhh");
            return conn;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if ( textBox1.Text == null)
            { MessageBox.Show("champs invalide !", "Veuillez Remplir tous les champs", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            else
            {
                OracleConnection conn = GetDBConnection();


                string requete_sql = "delete from EMPLOYE   where MATRICULE=:MATRICULE";


                OracleCommand cmd = conn.CreateCommand();
                cmd.CommandText = requete_sql;
                conn.Open();


                //OracleParameter idParam = new OracleParameter("id", OracleDbType.Int32);
                //idParam.Value = int.Parse(textBox1.Text);
                //cmd.Parameters.Add(idParam);




                cmd.Parameters.Add("MATRICULE", OracleDbType.Varchar2).Value = textBox1.Text;



                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount >= 1)
                    MessageBox.Show("Opération réussie !", "Supprimer employé", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 F = new Form1();
            F.Show();
            this.Hide();
        }
    }
}

