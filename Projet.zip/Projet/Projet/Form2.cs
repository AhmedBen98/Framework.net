﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
namespace Projet
{
    public partial class Form2 : Form
    {
     
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 F = new Form1();
            F.Show();
            this.Hide();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                Getempdata();
            }
        }

            private void Getempdata()
            {
            string connectionString = "DATA SOURCE = (DESCRIPTION ="
              + "(ADDRESS = (PROTOCOL = TCP)(HOST = LAPTOP-OPCS7AAB)(PORT = 1521))" +
  "(CONNECT_DATA =" +
   " (SERVER = DEDICATED)" +
   " (SERVICE_NAME = XE)" +
 " ) ); USER ID = SYSTEM;Password=manager;";


            OleDbConnection conn = new OleDbConnection();
          
            conn.ConnectionString = connectionString;
            conn.Open();
            

            OleDbCommand cmd = new OleDbCommand("Select * from EMPLOYE", conn);
            DataTable dt = new DataTable();

            conn.Open();
            OleDbDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();

            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
        }
    

