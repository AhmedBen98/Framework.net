﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace Projet
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        public OracleConnection GetDBConnection()
        {
            string connectionString = "DATA SOURCE = (DESCRIPTION ="
               + "(ADDRESS = (PROTOCOL = TCP)(HOST = LAPTOP-OPCS7AAB)(PORT = 1521))" +
   "(CONNECT_DATA =" +
    " (SERVER = DEDICATED)" +
    " (SERVICE_NAME = XE)" +
  " ) ); USER ID = SYSTEM;Password=manager;";


            OracleConnection conn = new OracleConnection(connectionString);

            //  conn.ConnectionString = connectionString;
            //MessageBox.Show("hhhhhh");
            return conn;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == null || textBox2.Text == "" || textBox3.Text == "" || radioButton1.Checked == false && radioButton2.Checked == false || comboBox1.Text == "")
            { MessageBox.Show("champs invalide !", "Veuillez Remplir tous les champs", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            else
            {
                OracleConnection conn = GetDBConnection();

                string requete_sql = "update EMPLOYE set NOM=:NOM,PRENOM=:PRENOM,FONCTION=:FONCTION where MATRICULE=5214";

                OracleCommand cmd = conn.CreateCommand();

                cmd.CommandText = requete_sql;

                conn.Open();


                OracleParameter nameParam = cmd.Parameters.Add("NOM", OracleDbType.Varchar2);
                nameParam.Value = textBox2.Text;

                cmd.Parameters.Add("PRENOM", OracleDbType.Varchar2).Value = textBox3.Text;

                OracleParameter FonctionParam = cmd.Parameters.Add("FONCTION", OracleDbType.Varchar2);
                FonctionParam.Value = comboBox1.SelectedItem.ToString();

                int rowCount = cmd.ExecuteNonQuery();

                if (rowCount >= 1)

                    MessageBox.Show("Opération réussie !", "modifier employé", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 F = new Form1();
            F.Show();
            this.Hide();
        }
    }
}
